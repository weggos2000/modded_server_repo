tag @s add MAILBOXES_SendGUI
scoreboard players operation @s MAILBOXES_IdGUI = .max MAILBOXES_IdGUI
summon chest_minecart ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,CustomDisplayTile:1b,Tags:["MAILBOXES_SendGUI"],CustomName:'{"text":"✉ Send Mail"}',DisplayState:{Name:"minecraft:red_shulker_box"}}
scoreboard players operation @e[type=chest_minecart,tag=MAILBOXES_SendGUI,limit=1,sort=nearest] MAILBOXES_IdGUI = @s MAILBOXES_IdGUI
scoreboard players add .max MAILBOXES_IdGUI 1