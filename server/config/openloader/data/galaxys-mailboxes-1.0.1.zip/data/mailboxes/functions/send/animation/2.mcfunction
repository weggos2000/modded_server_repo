execute as @a[scores={MAILBOXES_Integers=2}] run title @s actionbar [{"text":"|⛟","color":"#FF2A00"},{"text":"|||||||||","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=2}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 0.6
execute as @a[scores={MAILBOXES_Integers=2}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/3 2t