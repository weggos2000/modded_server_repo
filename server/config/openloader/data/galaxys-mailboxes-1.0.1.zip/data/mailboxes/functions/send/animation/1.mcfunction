scoreboard players set @s MAILBOXES_Integers 1
execute as @a[scores={MAILBOXES_Integers=1}] run title @s actionbar [{"text":"⛟","color":"#FF0000"},{"text":"||||||||||","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=1}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 0.5
execute as @a[scores={MAILBOXES_Integers=1}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/2 2t