data modify storage mailboxes:scan availability set from entity @s SelectedItem.tag.display.Name
execute store success score CheckAvailability MAILBOXES_Integers run data modify storage mailboxes:scan availability set from entity @e[type=block_display,tag=MAILBOXES_Mailbox,tag=!MAILBOXES_Scanned,limit=1,sort=arbitrary] CustomName
execute unless score CheckAvailability MAILBOXES_Integers matches 1 run tellraw @s {"text":"That address is being used.","color":"red"}
execute if score CheckAvailability MAILBOXES_Integers matches 1 run tag @e[type=block_display,tag=MAILBOXES_Mailbox,tag=!MAILBOXES_Scanned,limit=1,sort=arbitrary] add MAILBOXES_Scanned
execute unless score CheckAvailability MAILBOXES_Integers matches 1 run tag @e[type=block_display,tag=MAILBOXES_Mailbox,tag=MAILBOXES_Scanned] remove MAILBOXES_Scanned
execute if entity @e[type=block_display,tag=MAILBOXES_Mailbox,tag=!MAILBOXES_Scanned] if score CheckAvailability MAILBOXES_Integers matches 1 run function mailboxes:create/availability
execute unless entity @e[type=block_display,tag=MAILBOXES_Mailbox,tag=!MAILBOXES_Scanned] if score CheckAvailability MAILBOXES_Integers matches 1 run function mailboxes:create/area