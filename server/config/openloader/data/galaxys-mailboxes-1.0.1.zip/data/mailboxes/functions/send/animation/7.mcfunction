execute as @a[scores={MAILBOXES_Integers=7}] run title @s actionbar [{"text":"||||||⛟","color":"#FFF700"},{"text":"||||","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=7}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 1.1
execute as @a[scores={MAILBOXES_Integers=7}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/8 2t