tag @e[type=block_display,tag=MAILBOXES_Mailbox,tag=MAILBOXES_Scanned] remove MAILBOXES_Scanned
function mailboxes:send/slots/0
execute unless entity @e[type=block_display,tag=MAILBOXES_AddressFull] as @e[type=chest_minecart,tag=MAILBOXES_SendGUI] if score @s MAILBOXES_IdGUI = @p MAILBOXES_IdGUI run item replace entity @s container.2 with air
execute unless entity @e[type=block_display,tag=MAILBOXES_AddressFull] as @e[type=chest_minecart,tag=MAILBOXES_SendGUI] if score @s MAILBOXES_IdGUI = @p MAILBOXES_IdGUI run item replace entity @s container.20 with air
execute unless entity @e[type=block_display,tag=MAILBOXES_AddressFull] run scoreboard players set @s MAILBOXES_CrouchDetect 1
execute unless entity @e[type=block_display,tag=MAILBOXES_AddressFull] run function mailboxes:send/animation/1
execute if entity @e[type=block_display,tag=MAILBOXES_AddressFull] run tellraw @s {"text":"That Mailbox is full at the moment.","color":"red"}
tag @e[type=block_display,tag=MAILBOXES_Address] remove MAILBOXES_Address
tag @e[type=block_display,tag=MAILBOXES_AddressFull] remove MAILBOXES_AddressFull