tag @e[type=block_display,tag=MAILBOXES_Mailbox,tag=MAILBOXES_Scanned] remove MAILBOXES_Scanned
execute anchored eyes if block ^ ^ ^1 #mailboxes:mailbox run function mailboxes:create/initiate
execute anchored eyes unless block ^ ^ ^1 #mailboxes:mailbox run tellraw @s {"text":"Please stand right next to and face a valid container.","color":"red"}