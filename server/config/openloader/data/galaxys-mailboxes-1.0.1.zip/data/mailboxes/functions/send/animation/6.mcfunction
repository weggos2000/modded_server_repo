execute as @a[scores={MAILBOXES_Integers=6}] run title @s actionbar [{"text":"|||||⛟","color":"#FFD500"},{"text":"|||||","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=6}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 1
execute as @a[scores={MAILBOXES_Integers=6}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/7 2t