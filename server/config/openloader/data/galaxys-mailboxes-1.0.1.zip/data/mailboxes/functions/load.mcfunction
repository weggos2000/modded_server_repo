scoreboard objectives add CreateMailbox trigger
scoreboard objectives add MAILBOXES_Integers dummy
scoreboard objectives add MAILBOXES_IdGUI dummy
execute unless score .max MAILBOXES_IdGUI matches 1..2147483647 run scoreboard players set .max MAILBOXES_IdGUI 1
execute unless entity @a[tag=MAILBOXES_SendGUI] run scoreboard players set .max MAILBOXES_IdGUI 1
scoreboard objectives add MAILBOXES_CrouchDetect minecraft.custom:sneak_time
scoreboard objectives add MAILBOXES_SendDetect dummy