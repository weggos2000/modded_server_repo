execute as @a[scores={MAILBOXES_Integers=4}] run title @s actionbar [{"text":"|||⛟","color":"#FF6600"},{"text":"|||||||","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=4}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 0.8
execute as @a[scores={MAILBOXES_Integers=4}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/5 2t