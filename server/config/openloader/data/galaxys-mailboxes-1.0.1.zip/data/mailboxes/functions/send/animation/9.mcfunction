execute as @a[scores={MAILBOXES_Integers=9}] run title @s actionbar [{"text":"||||||||⛟","color":"#A2FF00"},{"text":"||","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=9}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 1.3
execute as @a[scores={MAILBOXES_Integers=9}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/10 2t