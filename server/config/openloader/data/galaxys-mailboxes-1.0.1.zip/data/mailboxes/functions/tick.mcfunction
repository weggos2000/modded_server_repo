# Create Mailbox
scoreboard players enable @a CreateMailbox
execute as @a[scores={CreateMailbox=1..}] at @s run function mailboxes:create/address
scoreboard players set @a CreateMailbox 0
# Send
execute as @e[type=interaction,tag=MAILBOXES_Postbox] on target unless entity @s[tag=MAILBOXES_SendGUI] at @s run function mailboxes:send/int_gui
execute as @a[tag=MAILBOXES_SendGUI] at @s run function mailboxes:send/gui
# Clear
clear @a gray_stained_glass_pane{MAILBOXES_Item:1b}
clear @a red_stained_glass_pane{MAILBOXES_Item:1b}
clear @a lime_stained_glass_pane{MAILBOXES_Item:1b}
kill @e[type=item,nbt={Item:{tag:{MAILBOXES_Item:1b}}}]
# Reset
execute as @e[type=interaction,tag=MAILBOXES_Postbox] run data remove entity @s interaction
execute as @e[type=interaction,tag=MAILBOXES_Postbox] run data remove entity @s attack
scoreboard players reset @a MAILBOXES_CrouchDetect