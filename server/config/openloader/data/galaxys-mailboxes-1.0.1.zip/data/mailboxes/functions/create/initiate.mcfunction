execute anchored eyes positioned ^ ^ ^1 align xyz run summon block_display ~0.5 ~0.5 ~0.5 {Tags:["MAILBOXES_Mailbox","MAILBOXES_MailboxPlaced"]}
execute anchored eyes positioned ^ ^ ^1 align xyz positioned ~0.5 ~0.5 ~0.5 run forceload add ~ ~
execute store success score CheckAvailability MAILBOXES_Integers run data modify storage mailboxes:scan availability set from entity @s SelectedItem.tag.display.Name
data modify entity @e[type=block_display,tag=MAILBOXES_MailboxPlaced,limit=1] CustomName set from storage mailboxes:scan availability
tag @e[type=block_display,tag=MAILBOXES_MailboxPlaced] remove MAILBOXES_MailboxPlaced
tellraw @s {"text":"Mailbox successfully created.","color":"green"}