execute as @a[scores={MAILBOXES_Integers=5}] run title @s actionbar [{"text":"||||⛟","color":"#FFA200"},{"text":"||||||","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=5}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 0.9
execute as @a[scores={MAILBOXES_Integers=5}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/6 2t