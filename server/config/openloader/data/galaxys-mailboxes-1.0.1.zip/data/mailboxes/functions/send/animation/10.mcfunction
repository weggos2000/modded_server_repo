execute as @a[scores={MAILBOXES_Integers=10}] run title @s actionbar [{"text":"|||||||||⛟","color":"#77FF00"},{"text":"|","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=10}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 1.4
execute as @a[scores={MAILBOXES_Integers=10}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/11 2t