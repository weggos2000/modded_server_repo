kill @e[type=block_display,tag=MAILBOXES_Postbox,distance=..1]
kill @e[type=interaction,tag=MAILBOXES_Postbox,distance=..1]