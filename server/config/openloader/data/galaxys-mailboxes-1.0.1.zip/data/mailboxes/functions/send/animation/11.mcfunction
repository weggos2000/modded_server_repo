execute as @a[scores={MAILBOXES_Integers=11}] run title @s actionbar [{"text":"||||||||||⛟","color":"#2BFF00"},{"text":"","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=11}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 1.5
execute as @a[scores={MAILBOXES_Integers=11}] run tellraw @s {"text":"Mail has successfully been sent.","color":"green"}
execute as @a[scores={MAILBOXES_Integers=11}] run scoreboard players reset @s MAILBOXES_Integers