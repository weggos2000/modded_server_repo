execute as @a[scores={MAILBOXES_Integers=3}] run title @s actionbar [{"text":"||⛟","color":"#FF4400"},{"text":"||||||||","color":"gray"}]
execute as @a[scores={MAILBOXES_Integers=3}] at @s run playsound block.note_block.bit master @s ~ ~ ~ 0.5 0.7
execute as @a[scores={MAILBOXES_Integers=3}] run scoreboard players add @s MAILBOXES_Integers 1
schedule function mailboxes:send/animation/4 2t